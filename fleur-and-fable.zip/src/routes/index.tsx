import { createFileRoute } from "@tanstack/react-router";
import heroBouquet from "@/assets/hero-bouquet.jpg";
import collectionCandles from "@/assets/collection-candles.jpg";
import collectionPipecleaner from "@/assets/collection-pipecleaner.jpg";
import collectionBouquets from "@/assets/collection-bouquets.jpg";
import studio from "@/assets/studio.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Fleur & Fable — Flowers, Pipe Cleaner Blooms & Candles" },
      {
        name: "description",
        content:
          "A peaceful boutique of fresh seasonal bouquets, everlasting pipe cleaner flowers, and hand-poured botanical candles.",
      },
      { property: "og:title", content: "Fleur & Fable — Flowers, Pipe Cleaner Blooms & Candles" },
      {
        property: "og:description",
        content:
          "A peaceful boutique of fresh seasonal bouquets, everlasting pipe cleaner flowers, and hand-poured botanical candles.",
      },
      { property: "og:image", content: heroBouquet },
      { name: "twitter:image", content: heroBouquet },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-petal-100 font-sans text-petal-600">
      {/* Navigation */}
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-8">
        <span className="font-display text-2xl italic tracking-tight text-petal-600">
          Fleur &amp; Fable
        </span>
        <div className="hidden space-x-8 text-sm tracking-wide sm:flex">
          <a href="#collections" className="transition-colors hover:text-petal-400">
            Collections
          </a>
          <a href="#story" className="transition-colors hover:text-petal-400">
            Our Story
          </a>
          <a href="#gifting" className="transition-colors hover:text-petal-400">
            Gifting
          </a>
        </div>
        <button className="text-sm uppercase tracking-widest">Cart (0)</button>
      </nav>

      {/* Hero Grid */}
      <section className="px-6 py-12">
        <div className="mx-auto max-w-7xl">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            <div className="relative lg:col-span-8">
              <img
                src={heroBouquet}
                alt="A wild bouquet of cherry blossoms and peonies in a ceramic vase"
                width={1280}
                height={960}
                className="aspect-[4/3] w-full rounded-[min(1vw,12px)] object-cover outline-1 -outline-offset-1 outline-black/5"
              />
            </div>

            <div className="flex flex-col justify-center lg:col-span-4 lg:pl-12">
              <h1 className="max-w-[20ch] text-balance font-display text-5xl leading-tight text-petal-600 sm:text-6xl lg:text-7xl">
                Kindness in every <span className="italic">bloom</span>.
              </h1>
              <p className="mt-8 max-w-[40ch] text-pretty text-lg leading-relaxed text-petal-400">
                A boutique collection of fresh stems, everlasting pipe cleaner flowers, and
                hand-poured botanical candles.
              </p>
              <div className="mt-10">
                <a
                  href="#collections"
                  className="inline-flex items-center rounded-full bg-petal-600 py-2 pl-2 pr-4 text-sm font-medium text-petal-100 ring-1 ring-petal-600 transition-transform hover:-translate-y-[1px]"
                >
                  <span className="mr-2 inline-block size-4 rounded-full bg-petal-100/20" />
                  Explore the Garden
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Collections */}
      <section id="collections" className="bg-petal-200/30 px-6 py-24">
        <div className="mx-auto max-w-7xl">
          <div className="mb-16 flex items-end justify-between">
            <h2 className="max-w-[35ch] text-balance font-display text-3xl font-medium">
              Curated Curiosities
            </h2>
            <a
              href="#collections"
              className="border-b border-petal-400 pb-1 text-sm uppercase tracking-widest"
            >
              View All
            </a>
          </div>

          <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-3">
            <Collection
              image={collectionCandles}
              alt="Artisan hand-poured candle with dried flower petals"
              title="The Solstice Collection"
              copy="Notes of bergamot, pressed rose, and morning mist."
            />
            <Collection
              image={collectionPipecleaner}
              alt="Handcrafted pipe cleaner cherry blossoms in a glass jar"
              title="Everlasting Softness"
              copy="Hand-sculpted textures that never fade or wilt."
            />
            <Collection
              image={collectionBouquets}
              alt="A fresh bouquet of ranunculus and sweet peas wrapped in craft paper"
              title="Weekly Gatherings"
              copy="Freshly cut stems delivered from the morning market."
            />
          </div>
        </div>
      </section>

      {/* About / Story */}
      <section id="story" className="px-6 py-32">
        <div className="mx-auto max-w-7xl">
          <div className="grid items-center gap-16 lg:grid-cols-2">
            <div className="order-2 lg:order-1">
              <img
                src={studio}
                alt="Our sunlit boutique studio with tools and flower petals on a wooden table"
                width={1024}
                height={1280}
                loading="lazy"
                className="aspect-[4/5] w-full rounded-[min(1vw,12px)] object-cover outline-1 -outline-offset-1 outline-black/5"
              />
            </div>
            <div className="order-1 lg:order-2">
              <span className="text-xs font-medium uppercase tracking-[0.3em] text-petal-400">
                Our Heart
              </span>
              <h2 className="mt-6 max-w-[24ch] text-balance font-display text-4xl leading-tight sm:text-5xl">
                Born in a sunlit <span className="italic">conservatory</span>
              </h2>
              <div className="mt-8 space-y-6">
                <p className="max-w-[48ch] text-pretty text-lg leading-relaxed">
                  Fleur &amp; Fable began with a single tray of hand-poured candles and a bunch of
                  wild roses. We believe that a home should feel like a sanctuary — a place of soft
                  light and gentle aromas.
                </p>
                <p className="max-w-[48ch] text-pretty text-lg leading-relaxed">
                  Whether it&apos;s the tactile charm of our pipe cleaner flowers or the ephemeral
                  beauty of a fresh bouquet, every piece is curated to bring a moment of peace to
                  your day.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Gentle CTA */}
      <section id="gifting" className="mx-auto mb-24 max-w-7xl px-6">
        <div className="rounded-[min(1vw,24px)] bg-petal-400/10 px-6 py-20 text-center ring-1 ring-black/5">
          <h2 className="mx-auto max-w-[30ch] text-balance font-display text-4xl leading-tight text-petal-600">
            Bring the garden indoors
          </h2>
          <p className="mx-auto mt-6 max-w-[56ch] text-pretty text-petal-600/80">
            Join our monthly garden letter for seasonal flower care tips and first access to our
            handcrafted collections.
          </p>
          <form
            className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row"
            onSubmit={(e) => e.preventDefault()}
          >
            <label htmlFor="newsletter-email" className="sr-only">
              Email address
            </label>
            <input
              id="newsletter-email"
              type="email"
              placeholder="Your email address"
              className="w-full max-w-sm rounded-full border-none bg-petal-100 px-6 py-3 text-sm ring-1 ring-petal-600/10 focus:outline-none focus:ring-petal-600 sm:w-80"
            />
            <button
              type="submit"
              className="w-full rounded-full bg-petal-600 px-8 py-3 text-sm font-medium text-petal-100 transition-transform hover:-translate-y-[1px] sm:w-auto"
            >
              Join the List
            </button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-petal-600/5 py-16">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-8 px-6 md:flex-row">
          <span className="font-display text-xl italic text-petal-600">Fleur &amp; Fable</span>
          <div className="flex gap-12 text-sm uppercase tracking-widest">
            <a href="#" className="transition-colors hover:text-petal-400">
              Instagram
            </a>
            <a href="#" className="transition-colors hover:text-petal-400">
              Pinterest
            </a>
            <a href="#" className="transition-colors hover:text-petal-400">
              Contact
            </a>
          </div>
          <p className="text-xs text-petal-400">© 2024 Fleur &amp; Fable. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

function Collection({
  image,
  alt,
  title,
  copy,
}: {
  image: string;
  alt: string;
  title: string;
  copy: string;
}) {
  return (
    <div className="group">
      <div className="overflow-hidden rounded-[min(1vw,12px)] ring-1 ring-black/5">
        <img
          src={image}
          alt={alt}
          width={800}
          height={1000}
          loading="lazy"
          className="aspect-[4/5] w-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
        />
      </div>
      <h3 className="mt-6 font-display text-2xl font-medium">{title}</h3>
      <p className="mt-2 max-w-[48ch] text-pretty text-sm text-petal-400">{copy}</p>
    </div>
  );
}
